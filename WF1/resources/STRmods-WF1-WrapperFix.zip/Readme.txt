 --- Wreckfest 1 - Bugged Wrapper Fix ---
		  = created by STRmods =

This is a fix for the broken error messages that appear with game crashes. 
This is especially useful for people creating mods as without this patch
error messages will appear broken with single character description and 
"Ok" button. So you will see things like error message "C" and "O" in
the button text. 

Installation:

Drag the wrapper folder from this archive into the installation 
root directory of Wreckfest. It will overwrite one file.

"Wreckfest\wrapper\thqnocfg.dat"

This won't cause any problems with online and is fully compatible with
unmodified Wreckfest players online.